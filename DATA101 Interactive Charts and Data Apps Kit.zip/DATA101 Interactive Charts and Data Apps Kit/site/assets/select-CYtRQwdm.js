import{S as t,r as n}from"./theme-BqwrCbkh.js";function r(e){return typeof e=="string"?new t([[document.querySelector(e)]],[document.documentElement]):new t([[e]],n)}export{r as s};
