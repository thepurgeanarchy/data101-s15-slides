# DATA101: Interactive Charts and Data Apps (Student Kit)

This kit contains:
- `data101-python-interactive-dash.pdf` (static PDF)
- `site/` (interactive Slidev build, includes the D3 lab under `/lab/`)
- `slides-python-interactive-dash.md` (source slides)

## Run the interactive slides + lab

1. In a terminal:

```bash
cd "site"
python3 -m http.server 8000
```

2. In your browser:
- Slides: `http://localhost:8000/`
- Lab (direct): `http://localhost:8000/lab/`

The slides include buttons like "Open interactive lab" that open the correct lab section in a new tab.

## Troubleshooting

- If you open the HTML files directly (double-click), you may see blank content due to browser security rules. Use the local server.
